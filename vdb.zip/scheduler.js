/**
 * VDB Diamond Scheduler
 * Runs every day at 12:00 AM (midnight) Indian Standard Time (IST)
 * IST = UTC+5:30
 */

const schedule = require('node-schedule');
const fs = require('fs');
const path = require('path');
const https = require('https');

// Configuration
const API_BASE_URL = 'apiservices.vdbapp.com';
const API_PATH = '/v2/diamonds';
const AUTH_TOKEN = 'iltz_Ie1tN0qm-ANqF7X6SRjwyhmMtzZsmqvyWOZ83I';
const API_KEY = '_eTAh9su9_0cnehpDpqM9xA';
const SHOP_NAME = 'aaveri-2.myshopify.com';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

// Map VDB fields to our schema
function mapDiamondToSchema(vdbDiamond) {
  return {
    id: vdbDiamond.id,
    sku: `VDB-${vdbDiamond.stock_num || vdbDiamond.id}`,
    vendorRef: vdbDiamond.vendor_id ? `vendor-${vdbDiamond.vendor_id}` : 'aurum-diamond-house',
    title: `${vdbDiamond.shape} ${vdbDiamond.size}ct ${vdbDiamond.color} ${vdbDiamond.clarity}`,
    shape: vdbDiamond.shape || 'Round',
    growthType: 'natural',
    carat: parseFloat(vdbDiamond.size) || 0,
    color: vdbDiamond.color || 'D',
    clarity: vdbDiamond.clarity || 'VS1',
    certificate: vdbDiamond.lab || 'GIA',
    certificateUrl: vdbDiamond.cert_url || '',
    cut: vdbDiamond.cut || 'Excellent',
    polish: vdbDiamond.polish || 'Excellent',
    symmetry: vdbDiamond.symmetry || 'Excellent',
    measurements: `${vdbDiamond.meas_length || 0}x${vdbDiamond.meas_width || 0}x${vdbDiamond.meas_depth || 0}`,
    tablePercent: parseFloat(vdbDiamond.table_percent) || 0,
    depthPercent: parseFloat(vdbDiamond.depth_percent) || 0,
    fluorescence: vdbDiamond.fluor_intensity || 'None',
    price: vdbDiamond.total_sales_price || vdbDiamond.price_per_carat || 0,
    availability: vdbDiamond.available ? 'available' : 'unavailable',
    publicationState: 'published',
    compatibleSettingIds: [],
    accentColor: '#f7edcc',
    cardCaption: `${vdbDiamond.cut} cut, ${vdbDiamond.polish} polish, ${vdbDiamond.symmetry} symmetry`,
    origin: vdbDiamond.country || 'USA',
    description: `${vdbDiamond.shape} natural diamond certified by ${vdbDiamond.lab || 'GIA'}.`,
    publishedAt: new Date().toISOString(),
    imageUrl: vdbDiamond.image_url || '',
    variantId: `${vdbDiamond.id}`,
  };
}

// Fetch diamonds from VDB API
function fetchDiamondsFromVDB(pageNumber = 1, pageSize = 50) {
  return new Promise((resolve, reject) => {
    const queryParams = new URLSearchParams({
      type: 'Diamond',
      page_number: pageNumber,
      page_size: pageSize,
      markup_mode: 'true',
      show_unavailable: 'true',
    });

    const options = {
      hostname: API_BASE_URL,
      path: `${API_PATH}?${queryParams}`,
      method: 'GET',
      headers: {
        'Authorization': `Token token=${AUTH_TOKEN}, api_key=${API_KEY}`,
        'Cache-Control': 'no-cache',
        'User-Agent': 'Node.js Diamond Scheduler',
      },
    };

    https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed);
        } catch (err) {
          reject(new Error(`Failed to parse response: ${err.message}`));
        }
      });
    }).on('error', reject).end();
  });
}

// Save diamonds to file
function saveDiamondsToFile(diamonds, filename) {
  const filepath = path.join(__dirname, 'data', 'manual_diamonds', filename);
  
  const dir = path.dirname(filepath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(filepath, JSON.stringify(diamonds, null, 2), 'utf-8');
  return filepath;
}

// Update variant mapping
function updateVariantMapping(diamonds) {
  const mappingFile = path.join(__dirname, 'data', 'manual_diamonds', 'shopify-variant-mapping.json');
  
  let existingMapping = [];
  if (fs.existsSync(mappingFile)) {
    existingMapping = JSON.parse(fs.readFileSync(mappingFile, 'utf-8'));
  }

  const newMapping = diamonds.map(diamond => ({
    diamondId: diamond.id,
    sku: diamond.sku,
    variantId: diamond.variantId,
    title: diamond.title,
    shape: diamond.shape,
    carat: diamond.carat,
    price: diamond.price,
  }));

  const mergedMapping = [
    ...newMapping,
    ...existingMapping.filter(existing => 
      !newMapping.some(n => n.diamondId === existing.diamondId)
    ),
  ];

  const dir = path.dirname(mappingFile);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(mappingFile, JSON.stringify(mergedMapping, null, 2), 'utf-8');
  return mappingFile;
}

// Create logs directory
function createLogsDirectory() {
  const logsDir = path.join(__dirname, 'logs');
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  return logsDir;
}

// Log to file and console
function log(message, level = 'info') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  
  // Console output with colors
  let colorCode = '';
  switch(level) {
    case 'success': colorCode = colors.green; break;
    case 'error': colorCode = colors.yellow; break;
    case 'info': colorCode = colors.blue; break;
    case 'debug': colorCode = colors.cyan; break;
    default: colorCode = colors.reset;
  }
  
  console.log(`${colorCode}${logMessage}${colors.reset}`);
  
  // File output
  const logsDir = createLogsDirectory();
  const logFile = path.join(logsDir, 'scheduler.log');
  fs.appendFileSync(logFile, logMessage + '\n', 'utf-8');
}

// Main fetch and update function
async function runFetchAndUpdate() {
  const startTime = new Date();
  log('═══════════════════════════════════════════════════════', 'info');
  log('🔄 Starting VDB Diamond Fetch...', 'info');
  log(`📅 Time: ${startTime.toISOString()}`, 'info');
  log(`🕐 Indian Time (IST): ${new Date(startTime.getTime() + 5.5 * 60 * 60 * 1000).toLocaleString('en-IN')}`, 'info');

  try {
    log('📡 Fetching diamonds from VDB API...', 'debug');
    const response = await fetchDiamondsFromVDB(1, 100);

    if (!response.response || !response.response.body || !response.response.body.diamonds) {
      throw new Error('Invalid API response format');
    }

    const vdbDiamonds = response.response.body.diamonds;
    log(`✓ Retrieved ${vdbDiamonds.length} diamonds from API`, 'success');

    // Map to schema
    log('🔄 Mapping diamonds to schema...', 'debug');
    const mappedDiamonds = vdbDiamonds.map(mapDiamondToSchema);

    // Save to file
    log('💾 Saving diamonds...', 'debug');
    const savedPath = saveDiamondsToFile(mappedDiamonds, `${SHOP_NAME}.json`);
    log(`✓ Saved ${mappedDiamonds.length} diamonds to ${savedPath}`, 'success');

    // Update mapping
    log('📝 Updating variant mapping...', 'debug');
    const mappingPath = updateVariantMapping(mappedDiamonds);
    log(`✓ Updated variant mapping at ${mappingPath}`, 'success');

    // Summary
    const endTime = new Date();
    const duration = ((endTime - startTime) / 1000).toFixed(2);
    log(`⏱️  Duration: ${duration} seconds`, 'info');
    log('✅ Process completed successfully!', 'success');
    log('═══════════════════════════════════════════════════════', 'info');
    log('', 'info');

  } catch (error) {
    log(`❌ Error: ${error.message}`, 'error');
    log(`📍 Stack: ${error.stack}`, 'error');
    log('═══════════════════════════════════════════════════════', 'info');
    log('', 'info');
  }
}

// Get next run time (12 AM IST)
function getNextRunTime() {
  // Current time in IST
  const now = new Date();
  const istNow = new Date(now.getTime() + 5.5 * 60 * 60 * 1000);
  
  // Next 12 AM IST
  const nextRun = new Date(istNow);
  nextRun.setHours(0, 0, 0, 0);
  nextRun.setDate(nextRun.getDate() + 1);
  
  // Convert back to UTC
  const nextRunUTC = new Date(nextRun.getTime() - 5.5 * 60 * 60 * 1000);
  return nextRunUTC;
}

// Schedule function
function scheduleTask() {
  log(`${colors.bright}🚀 VDB Diamond Scheduler Started${colors.reset}`, 'info');
  log(`📅 Current time: ${new Date().toISOString()}`, 'info');
  
  const nextRun = getNextRunTime();
  log(`⏰ Next run scheduled at: ${nextRun.toISOString()}`, 'info');
  log(`🕐 In Indian Time (IST): 12:00 AM`, 'info');
  log('', 'info');

  // Schedule: Every day at 12 AM IST
  // IST = UTC + 5:30, so 12 AM IST = 6:30 PM previous day UTC
  // Using cron-like syntax: "0 30 18 * * *" (but node-schedule is different)
  
  // Using rule-based scheduling:
  // 12 AM IST = 18:30 UTC (previous day)
  const rule = new schedule.RecurrenceRule();
  rule.hour = 18;
  rule.minute = 30;
  rule.second = 0;

  const job = schedule.scheduleJob(rule, async function() {
    log('', 'info');
    log(`${colors.bright}⏰ Scheduled Task Triggered!${colors.reset}`, 'info');
    await runFetchAndUpdate();
  });

  log(`${colors.cyan}Scheduler is running. Press Ctrl+C to stop.${colors.reset}`, 'info');
  log('', 'info');

  return job;
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  log('', 'info');
  log('🛑 Scheduler stopping...', 'info');
  schedule.gracefulShutdown();
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('', 'info');
  log('🛑 Scheduler stopping (SIGTERM)...', 'info');
  schedule.gracefulShutdown();
  process.exit(0);
});

// Start the scheduler
if (require.main === module) {
  scheduleTask();
}

module.exports = { scheduleTask, runFetchAndUpdate };
