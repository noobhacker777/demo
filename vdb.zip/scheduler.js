/**
 * VDB Diamond Scheduler
 * Runs immediately, then repeats every 24 hours.
 */

const fs = require('fs');
const path = require('path');
const { runFetchAndUpdate } = require('./fetch-and-update-diamonds');

const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

const DAY_IN_MS = 24 * 60 * 60 * 1000;
let runInProgress = false;
let nextRunTimer = null;

function createLogsDirectory() {
  const logsDir = path.join(__dirname, 'logs');

  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }

  return logsDir;
}

function log(message, level = 'info') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;

  let colorCode = colors.reset;
  switch (level) {
    case 'success':
      colorCode = colors.green;
      break;
    case 'error':
      colorCode = colors.yellow;
      break;
    case 'info':
      colorCode = colors.blue;
      break;
    case 'debug':
      colorCode = colors.cyan;
      break;
  }

  console.log(`${colorCode}${logMessage}${colors.reset}`);

  const logsDir = createLogsDirectory();
  const logFile = path.join(logsDir, 'scheduler.log');
  fs.appendFileSync(logFile, `${logMessage}\n`, 'utf-8');
}

function formatNextRunTime() {
  return new Date(Date.now() + DAY_IN_MS).toISOString();
}

async function runScheduledFetch() {
  if (runInProgress) {
    log('Previous refresh is still running. Skipping this cycle.', 'info');
    return;
  }

  runInProgress = true;
  const startTime = new Date();

  log('════════════════════════════════════════════════════════════════', 'info');
  log('🔄 Starting VDB Diamond refresh...', 'info');
  log(`📅 Time: ${startTime.toISOString()}`, 'info');

  try {
    const result = await runFetchAndUpdate();
    const endTime = new Date();
    const duration = ((endTime - startTime) / 1000).toFixed(2);

    if (result && result.shopifySync && result.shopifySync.enabled) {
      const created = result.shopifySync.results.filter((entry) => entry.action === 'created').length;
      const updated = result.shopifySync.results.filter((entry) => entry.action === 'updated').length;
      const failed = result.shopifySync.results.filter((entry) => entry.error).length;
      log(`✓ Shopify sync complete: ${created} created, ${updated} updated, ${failed} failed`, 'success');
    } else {
      log('ℹ Shopify sync skipped because credentials were not provided.', 'info');
    }

    log(`⏱️  Duration: ${duration} seconds`, 'info');
    log('✅ Refresh completed successfully!', 'success');
    log(`⏰ Next refresh target: ${formatNextRunTime()}`, 'info');
    log('════════════════════════════════════════════════════════════════', 'info');
    log('', 'info');
  } catch (error) {
    log(`❌ Error: ${error.message}`, 'error');
    log(`📍 Stack: ${error.stack}`, 'error');
    log('════════════════════════════════════════════════════════════════', 'info');
    log('', 'info');
  } finally {
    runInProgress = false;
  }
}

function scheduleTask() {
  log(`${colors.bright}🚀 VDB Diamond Scheduler Started${colors.reset}`, 'info');
  log(`📅 Current time: ${new Date().toISOString()}`, 'info');
  log('🕐 Refresh interval: every 24 hours', 'info');
  log('', 'info');

  runScheduledFetch();

  nextRunTimer = setInterval(() => {
    runScheduledFetch();
  }, DAY_IN_MS);

  log(`${colors.cyan}Scheduler is running. Press Ctrl+C to stop.${colors.reset}`, 'info');
  log('', 'info');

  return nextRunTimer;
}

process.on('SIGINT', () => {
  log('', 'info');
  log('🛑 Scheduler stopping...', 'info');
  if (nextRunTimer) {
    clearInterval(nextRunTimer);
  }
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('', 'info');
  log('🛑 Scheduler stopping (SIGTERM)...', 'info');
  if (nextRunTimer) {
    clearInterval(nextRunTimer);
  }
  process.exit(0);
});

if (require.main === module) {
  scheduleTask();
}

module.exports = { scheduleTask, runScheduledFetch };
