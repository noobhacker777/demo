# VDB Diamond Fetch & Update Script

This project provides tools to fetch diamond inventory from the VDB API and automatically map it to your local schema.

## Overview

The scripts fetch diamonds from the VDB API (apiservices.vdbapp.com) and convert them to your standardized diamond schema format, saving them to JSON files and updating variant mappings.

## Files

- `fetch-and-update-diamonds.js` - Node.js implementation
- `fetch-and-update-diamonds.py` - Python implementation
- `README.md` - This file

## Features

✅ Fetch diamonds from VDB API  
✅ Map VDB fields to your schema  
✅ Save diamonds to `data/manual_diamonds/{shop}.json`  
✅ Update variant mapping file  
✅ Handle multiple pages of results  
✅ Merge with existing diamonds (no duplicates)  

## Schema Mapping

The script maps VDB API fields to your schema:

| Schema Field | VDB API Field | Default |
|---|---|---|
| id | id | - |
| sku | stock_num | VDB-{id} |
| vendorRef | vendor_id | aurum-diamond-house |
| title | shape + size + color + clarity | - |
| shape | shape | Round |
| growthType | (hardcoded) | natural |
| carat | size | 0 |
| color | color | D |
| clarity | clarity | VS1 |
| certificate | lab | GIA |
| certificateUrl | cert_url | - |
| cut | cut | Excellent |
| polish | polish | Excellent |
| symmetry | symmetry | Excellent |
| measurements | meas_length x meas_width x meas_depth | - |
| tablePercent | table_percent | 0 |
| depthPercent | depth_percent | 0 |
| fluorescence | fluor_intensity | None |
| price | total_sales_price or price_per_carat | 0 |
| availability | available (1/0) | available/unavailable |
| publicationState | (hardcoded) | published |
| imageUrl | image_url | - |

## Installation & Usage

### Using Node.js

```bash
# Install dependencies (if needed)
npm install

# Run the script
node fetch-and-update-diamonds.js
```

### Using Python

```bash
# Install dependencies
pip install requests

# Run the script
python fetch-and-update-diamonds.py

# Or make it executable on Linux/Mac
chmod +x fetch-and-update-diamonds.py
./fetch-and-update-diamonds.py
```

### Configuration

Edit the constants in the script to customize:

```javascript
// In .js file
const AUTH_TOKEN = 'your-token';
const API_KEY = 'your-api-key';
const SHOP_NAME = 'aaveri-2.myshopify.com';
```

```python
# In .py file
AUTH_TOKEN = "your-token"
API_KEY = "your-api-key"
SHOP_NAME = "aaveri-2.myshopify.com"
```

## Output

The script creates/updates:

1. **`data/manual_diamonds/{shop-name}.json`**
   - Array of diamonds with your schema
   - Overwrites existing file
   - Example:
   ```json
   [
     {
       "id": 48280839454969,
       "sku": "VDB-YG-3652",
       "title": "Round 1.5ct E VS1",
       "carat": 1.5,
       "shape": "round",
       ...
     }
   ]
   ```

2. **`data/manual_diamonds/shopify-variant-mapping.json`**
   - Maps diamondId → variantId for Shopify
   - Merges with existing entries
   - Example:
   ```json
   [
     {
       "diamondId": 48280839454969,
       "sku": "VDB-YG-3652",
       "variantId": "48310060613881",
       "title": "Round 1.5ct E VS1",
       "carat": 1.5,
       "price": 11000
     }
   ]
   ```

3. **Optional Shopify sync**
   - When Shopify credentials are provided, the Node scripts will upsert products in Shopify by SKU.
   - The updater first tries to match an existing variant by SKU.
   - If no match is found, it creates a new product with a default variant.
   - Configure all stores in `SHOPIFY_STORES_JSON`.

## API Authentication

The scripts use VDB API credentials. Current credentials:

```
Token: iltz_Ie1tN0qm-ANqF7X6SRjwyhmMtzZsmqvyWOZ83I
API Key: _eTAh9su9_0cnehpDpqM9xA
```

To get your own credentials, contact: customapp.support@vdbapp.com

## Shopify Sync

The Node.js scripts can also update Shopify products after fetching VDB diamonds.

### Environment array

Set `SHOPIFY_STORES_JSON` to a JSON array of all stores:

```bash
SHOPIFY_STORES_JSON=[{"shopDomain":"store1.myshopify.com","accessToken":"token1","apiVersion":"2024-10"},{"shopDomain":"store2.myshopify.com","accessToken":"token2","apiVersion":"2024-10"}]
```

### Behavior

- Matches existing Shopify variants by SKU.
- Updates the product title, description, vendor, tags, and variant price when a match exists.
- Creates a new Shopify product when no matching SKU is found.
- Stores Shopify IDs in `data/manual_diamonds/shopify-variant-mapping.json` for later runs.

## VDB API Reference

### Endpoint
```
GET https://apiservices.vdbapp.com/v2/diamonds
```

### Query Parameters
- `type=Diamond` - Fetch natural diamonds (or `Lab_grown_Diamond`)
- `page_number` - Page number (1-based)
- `page_size` - Results per page (10-100, recommended <50)
- `markup_mode=true` - Include markup pricing
- `show_unavailable=true` - Include unavailable items
- Additional filters: colors, clarity, size, labs, etc.

### Response Structure
```json
{
  "response": {
    "body": {
      "diamonds": [
        {
          "id": 11136398,
          "stock_num": "YG-3652",
          "size": "3.22",
          "shape": "Round",
          "color": "E",
          "clarity": "VVS1",
          ...
        }
      ],
      "total_diamonds_found": 132
    },
    "header": {
      "status": 200
    }
  }
}
```

## Troubleshooting

### "Invalid API response format"
- Check authentication token and API key
- Verify API endpoint is reachable
- Check network connection

### "Failed to parse response" (Node.js)
- The API might have changed its response format
- Check the raw API response
- Update the mapping function if needed

### Permission error when saving files
- Ensure `data/manual_diamonds/` directory exists
- Check write permissions on the directory
- Run with appropriate privileges

### Duplicate diamonds in mapping
- The script automatically deduplicates by `diamondId`
- Older entries are kept if not in the new fetch
- Manual cleanup: Edit the mapping JSON file directly

## Advanced Usage

### Fetch multiple shops
```bash
# Add additional enabled shop entries in config.json.
# Each shop can define its own output_file and Shopify credentials.
```

### Fetch Lab-Grown Diamonds
In the fetch function, change:
```javascript
type: 'Diamond'  // Change to 'Lab_grown_Diamond'
```

### Adjust page size
```javascript
// Fetch more results at once (slower but fewer requests)
await fetchDiamondsFromVDB(1, 100);
```

### Add custom filters
```javascript
const queryParams = new URLSearchParams({
  type: 'Diamond',
  // Add more filters:
  color_from: 'D',
  color_to: 'H',
  clarity_from: 'VS1',
  clarity_to: 'IF',
  size_from: '0.5',
  size_to: '5',
  labs: ['GIA', 'AGS'],
});
```

## Data Flow

```
VDB API
  ↓
fetch_diamonds_from_vdb()
  ↓
[VDB diamond objects]
  ↓
map_diamond_to_schema()
  ↓
[Mapped diamonds in your schema]
  ↓
├─ save_diamonds_to_file()
│  └─ data/manual_diamonds/{shop}.json
│
└─ update_variant_mapping()
   └─ data/manual_diamonds/shopify-variant-mapping.json
```

## Example: Complete Workflow

1. **Run the fetch script:**
   ```bash
   python fetch-and-update-diamonds.py
   ```

2. **Script output:**
   ```
   🔄 Starting VDB Diamond Fetch...
   
   📡 Fetching diamonds from VDB API...
   ✓ Retrieved 50 diamonds from API
   
   🔄 Mapping diamonds to schema...
   
   💾 Saving diamonds...
   ✓ Saved 50 diamonds to data/manual_diamonds/aaveri-2.myshopify.com.json
   
   📝 Updating variant mapping...
   ✓ Updated variant mapping with 50 entries
   
   ✅ Process completed successfully!
   ```

3. **Your files are now updated:**
   - ✅ `data/manual_diamonds/aaveri-2.myshopify.com.json` - 50 new diamonds
   - ✅ `data/manual_diamonds/shopify-variant-mapping.json` - Updated with new variants

## Automation (Optional)

### Node.js - Schedule with cron
```bash
# Add to crontab (runs daily at 2 AM)
0 2 * * * cd /path/to/vdb && node fetch-and-update-diamonds.js
```

### Python - Schedule with cron
```bash
# Add to crontab (runs daily at 2 AM)
0 2 * * * cd /path/to/vdb && /usr/bin/python3 fetch-and-update-diamonds.py
```

### Windows - Task Scheduler
1. Open Task Scheduler
2. Create new task
3. Set trigger: Daily at 2 AM
4. Set action: `python fetch-and-update-diamonds.py` in your vdb directory

## Support & Contact

- VDB Support: customapp.support@vdbapp.com
- API Documentation: https://documenter.getpostman.com/view/3555432/2sB3HqGxjR
- Check your specific credentials and permissions

## License

For use with VDB API. Follow VDB terms of service.
