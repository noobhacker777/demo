#!/bin/bash

# VDB Diamond Scheduler - VPS Setup
# Run: bash setup-vps.sh

set -e

echo "═══════════════════════════════════════════════════════"
echo "🚀 VDB Diamond Scheduler - VPS Setup"
echo "═══════════════════════════════════════════════════════"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Install: curl https://nodejs.org/ | bash"
    exit 1
fi

NODE_VERSION=$(node -v)
echo "✓ Node.js $NODE_VERSION found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install node-schedule

# Install PM2 globally
echo ""
echo "📦 Installing PM2..."
npm install -g pm2

# Create logs directory
mkdir -p logs
echo "✓ Logs directory created"

# Start scheduler with PM2
echo ""
echo "🚀 Starting scheduler with PM2..."
pm2 start scheduler.js --name "vdb-scheduler"
pm2 save

# Display status
echo ""
echo "═══════════════════════════════════════════════════════"
echo "✅ Setup Complete!"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "📋 Next Steps:"
echo "  1. Make PM2 auto-start on reboot:"
echo "     pm2 startup"
echo "     pm2 save"
echo ""
echo "  2. View logs:"
echo "     pm2 logs vdb-scheduler"
echo ""
echo "  3. Check status:"
echo "     pm2 status"
echo ""
echo "✓ Scheduler running at 12:00 AM IST daily"
echo ""
