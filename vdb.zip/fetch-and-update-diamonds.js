const https = require('https');
const fs = require('fs');
const path = require('path');

// Configuration
const API_BASE_URL = 'apiservices.vdbapp.com';
const API_PATH = '/v2/diamonds';
const AUTH_TOKEN = 'iltz_Ie1tN0qm-ANqF7X6SRjwyhmMtzZsmqvyWOZ83I';
const API_KEY = '_eTAh9su9_0cnehpDpqM9xA';
const SHOP_NAME = 'aaveri-2.myshopify.com';

// Map VDB API fields to our diamond schema
function mapDiamondToSchema(vdbDiamond) {
  return {
    id: vdbDiamond.id,
    sku: `VDB-${vdbDiamond.stock_num || vdbDiamond.id}`,
    vendorRef: vdbDiamond.vendor_id ? `vendor-${vdbDiamond.vendor_id}` : 'aurum-diamond-house',
    title: `${vdbDiamond.shape} ${vdbDiamond.size}ct ${vdbDiamond.color} ${vdbDiamond.clarity}`,
    shape: vdbDiamond.shape || 'Round',
    growthType: 'natural',
    carat: parseFloat(vdbDiamond.size) || 0,
    color: vdbDiamond.color || 'D',
    clarity: vdbDiamond.clarity || 'VS1',
    certificate: vdbDiamond.lab || 'GIA',
    certificateUrl: vdbDiamond.cert_url || '',
    cut: vdbDiamond.cut || 'Excellent',
    polish: vdbDiamond.polish || 'Excellent',
    symmetry: vdbDiamond.symmetry || 'Excellent',
    measurements: `${vdbDiamond.meas_length || 0}x${vdbDiamond.meas_width || 0}x${vdbDiamond.meas_depth || 0}`,
    tablePercent: parseFloat(vdbDiamond.table_percent) || 0,
    depthPercent: parseFloat(vdbDiamond.depth_percent) || 0,
    fluorescence: vdbDiamond.fluor_intensity || 'None',
    price: vdbDiamond.total_sales_price || vdbDiamond.price_per_carat || 0,
    availability: vdbDiamond.available ? 'available' : 'unavailable',
    publicationState: 'published',
    compatibleSettingIds: [],
    accentColor: '#f7edcc',
    cardCaption: `${vdbDiamond.cut} cut, ${vdbDiamond.polish} polish, ${vdbDiamond.symmetry} symmetry`,
    origin: vdbDiamond.country || 'USA',
    description: `${vdbDiamond.shape} natural diamond certified by ${vdbDiamond.lab || 'GIA'}.`,
    publishedAt: new Date().toISOString(),
    imageUrl: vdbDiamond.image_url || '',
    variantId: `${vdbDiamond.id}`,
  };
}

// Fetch diamonds from VDB API
async function fetchDiamondsFromVDB(pageNumber = 1, pageSize = 50) {
  return new Promise((resolve, reject) => {
    const queryParams = new URLSearchParams({
      type: 'Diamond',
      page_number: pageNumber,
      page_size: pageSize,
      markup_mode: 'true',
      show_unavailable: 'true',
    });

    const options = {
      hostname: API_BASE_URL,
      path: `${API_PATH}?${queryParams}`,
      method: 'GET',
      headers: {
        'Authorization': `Token token=${AUTH_TOKEN}, api_key=${API_KEY}`,
        'Cache-Control': 'no-cache',
        'User-Agent': 'Node.js Diamond Fetch',
      },
    };

    https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed);
        } catch (err) {
          reject(new Error(`Failed to parse response: ${err.message}`));
        }
      });
    }).on('error', reject).end();
  });
}

// Save diamonds to file
function saveDiamondsToFile(diamonds, filename) {
  const filepath = path.join(__dirname, 'data', 'manual_diamonds', filename);
  
  // Create directory if it doesn't exist
  const dir = path.dirname(filepath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(filepath, JSON.stringify(diamonds, null, 2), 'utf-8');
  console.log(`✓ Saved ${diamonds.length} diamonds to ${filepath}`);
}

// Update variant mapping
function updateVariantMapping(diamonds) {
  const mappingFile = path.join(__dirname, 'data', 'manual_diamonds', 'shopify-variant-mapping.json');
  
  let existingMapping = [];
  if (fs.existsSync(mappingFile)) {
    existingMapping = JSON.parse(fs.readFileSync(mappingFile, 'utf-8'));
  }

  const newMapping = diamonds.map(diamond => ({
    diamondId: diamond.id,
    sku: diamond.sku,
    variantId: diamond.variantId,
    title: diamond.title,
    shape: diamond.shape,
    carat: diamond.carat,
    price: diamond.price,
  }));

  // Merge with existing, avoiding duplicates
  const mergedMapping = [
    ...newMapping,
    ...existingMapping.filter(existing => 
      !newMapping.some(n => n.diamondId === existing.diamondId)
    ),
  ];

  fs.writeFileSync(mappingFile, JSON.stringify(mergedMapping, null, 2), 'utf-8');
  console.log(`✓ Updated variant mapping with ${mergedMapping.length} entries`);
}

// Main execution
async function main() {
  console.log('🔄 Starting VDB Diamond Fetch...\n');

  try {
    console.log('📡 Fetching diamonds from VDB API...');
    const response = await fetchDiamondsFromVDB(1, 100);

    if (!response.response || !response.response.body || !response.response.body.diamonds) {
      throw new Error('Invalid API response format');
    }

    const vdbDiamonds = response.response.body.diamonds;
    console.log(`✓ Retrieved ${vdbDiamonds.length} diamonds from API\n`);

    // Map to our schema
    console.log('🔄 Mapping diamonds to schema...');
    const mappedDiamonds = vdbDiamonds.map(mapDiamondToSchema);

    // Save to files
    console.log('\n💾 Saving diamonds...');
    saveDiamondsToFile(mappedDiamonds, `${SHOP_NAME}.json`);

    // Update variant mapping
    console.log('📝 Updating variant mapping...');
    updateVariantMapping(mappedDiamonds);

    // Summary
    console.log('\n✅ Process completed successfully!\n');
    console.log('Summary:');
    console.log(`  • Total diamonds fetched: ${mappedDiamonds.length}`);
    console.log(`  • Saved to: data/manual_diamonds/${SHOP_NAME}.json`);
    console.log(`  • Updated: data/manual_diamonds/shopify-variant-mapping.json`);
    
    // Show sample diamond
    console.log('\n📊 Sample diamond:');
    console.log(JSON.stringify(mappedDiamonds[0], null, 2));

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

main();
