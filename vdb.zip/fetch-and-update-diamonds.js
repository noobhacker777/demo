const fs = require('fs');
const path = require('path');
const https = require('https');

require('./load-env');

const { syncDiamondsToShopify } = require('./shopify-sync');

// Configuration
const API_BASE_URL = 'apiservices.vdbapp.com';
const API_PATH = '/v2/diamonds';
const AUTH_TOKEN = 'iltz_Ie1tN0qm-ANqF7X6SRjwyhmMtzZsmqvyWOZ83I';
const API_KEY = '_eTAh9su9_0cnehpDpqM9xA';
const SHOP_NAME = 'aaveri-2.myshopify.com';
const DEFAULT_OUTPUT_FILE = path.join('data', 'manual_diamonds', `${SHOP_NAME}.json`);
const DEFAULT_MAPPING_FILE = path.join('data', 'manual_diamonds', 'shopify-variant-mapping.json');

function loadConfig() {
  const configPath = path.join(__dirname, 'config.json');

  if (!fs.existsSync(configPath)) {
    return null;
  }

  return JSON.parse(fs.readFileSync(configPath, 'utf-8'));
}

function getActiveShops(config) {
  const shops = config && Array.isArray(config.shops) ? config.shops : [];
  const enabledShops = shops.filter((shop) => shop && shop.enabled !== false);

  if (enabledShops.length) {
    return enabledShops.map((shop) => ({
      name: shop.name || SHOP_NAME,
      outputFile: shop.output_file || DEFAULT_OUTPUT_FILE,
      shopify: shop.shopify || null,
    }));
  }

  return [
    {
      name: SHOP_NAME,
      outputFile: DEFAULT_OUTPUT_FILE,
      shopify: null,
    },
  ];
}

function mapDiamondToSchema(vdbDiamond) {
  return {
    id: vdbDiamond.id,
    sku: `VDB-${vdbDiamond.stock_num || vdbDiamond.id}`,
    vendorRef: vdbDiamond.vendor_id ? `vendor-${vdbDiamond.vendor_id}` : 'aurum-diamond-house',
    title: `${vdbDiamond.shape} ${vdbDiamond.size}ct ${vdbDiamond.color} ${vdbDiamond.clarity}`,
    shape: vdbDiamond.shape || 'Round',
    growthType: 'natural',
    carat: parseFloat(vdbDiamond.size) || 0,
    color: vdbDiamond.color || 'D',
    clarity: vdbDiamond.clarity || 'VS1',
    certificate: vdbDiamond.lab || 'GIA',
    certificateUrl: vdbDiamond.cert_url || '',
    cut: vdbDiamond.cut || 'Excellent',
    polish: vdbDiamond.polish || 'Excellent',
    symmetry: vdbDiamond.symmetry || 'Excellent',
    measurements: `${vdbDiamond.meas_length || 0}x${vdbDiamond.meas_width || 0}x${vdbDiamond.meas_depth || 0}`,
    tablePercent: parseFloat(vdbDiamond.table_percent) || 0,
    depthPercent: parseFloat(vdbDiamond.depth_percent) || 0,
    fluorescence: vdbDiamond.fluor_intensity || 'None',
    price: vdbDiamond.total_sales_price || vdbDiamond.price_per_carat || 0,
    availability: vdbDiamond.available ? 'available' : 'unavailable',
    publicationState: 'published',
    compatibleSettingIds: [],
    accentColor: '#f7edcc',
    cardCaption: `${vdbDiamond.cut} cut, ${vdbDiamond.polish} polish, ${vdbDiamond.symmetry} symmetry`,
    origin: vdbDiamond.country || 'USA',
    description: `${vdbDiamond.shape} natural diamond certified by ${vdbDiamond.lab || 'GIA'}.`,
    publishedAt: new Date().toISOString(),
    imageUrl: vdbDiamond.image_url || '',
    variantId: `${vdbDiamond.id}`,
  };
}

function fetchDiamondsFromVDB(pageNumber = 1, pageSize = 50) {
  return new Promise((resolve, reject) => {
    const queryParams = new URLSearchParams({
      type: 'Diamond',
      page_number: pageNumber,
      page_size: pageSize,
      markup_mode: 'true',
      show_unavailable: 'true',
    });

    const options = {
      hostname: API_BASE_URL,
      path: `${API_PATH}?${queryParams}`,
      method: 'GET',
      headers: {
        Authorization: `Token token=${AUTH_TOKEN}, api_key=${API_KEY}`,
        'Cache-Control': 'no-cache',
        'User-Agent': 'Node.js Diamond Fetch',
      },
    };

    https
      .request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (error) {
            reject(new Error(`Failed to parse response: ${error.message}`));
          }
        });
      })
      .on('error', reject)
      .end();
  });
}

function saveDiamondsToFile(diamonds, outputPath) {
  const filepath = path.isAbsolute(outputPath) ? outputPath : path.join(__dirname, outputPath);
  const dir = path.dirname(filepath);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(filepath, JSON.stringify(diamonds, null, 2), 'utf-8');
}

function updateVariantMapping(diamonds, shopifyResults = [], mappingPath = DEFAULT_MAPPING_FILE) {
  const mappingFile = path.isAbsolute(mappingPath) ? mappingPath : path.join(__dirname, mappingPath);
  let existingMapping = [];

  if (fs.existsSync(mappingFile)) {
    existingMapping = JSON.parse(fs.readFileSync(mappingFile, 'utf-8'));
  }

  const existingByDiamondId = new Map(existingMapping.map((entry) => [entry.diamondId, entry]));

  const newMapping = diamonds.map((diamond) => {
    const existing = existingByDiamondId.get(diamond.id) || {};
    const diamondResults = shopifyResults.filter((result) => result && result.diamondId === diamond.id && !result.error && !result.skipped);
    const existingStores = Array.isArray(existing.shopifyStores) ? existing.shopifyStores : [];
    const nextStores = diamondResults.map((result) => ({
      shopDomain: result.shopDomain || null,
      shopifyProductId: result.shopifyProductId || null,
      shopifyVariantId: result.shopifyVariantId || null,
      shopifyHandle: result.shopifyHandle || null,
    }));
    const mergedStores = [...existingStores, ...nextStores].filter((store, index, all) => {
      const key = `${store.shopDomain || ''}:${store.shopifyProductId || ''}:${store.shopifyVariantId || ''}`;
      return index === all.findIndex((candidate) => `${candidate.shopDomain || ''}:${candidate.shopifyProductId || ''}:${candidate.shopifyVariantId || ''}` === key);
    });

    return {
      ...existing,
      diamondId: diamond.id,
      sku: diamond.sku,
      variantId: diamond.variantId,
      title: diamond.title,
      shape: diamond.shape,
      carat: diamond.carat,
      price: diamond.price,
      ...(diamondResults.length
        ? {
            shopifyProductId: diamondResults[0].shopifyProductId || null,
            shopifyVariantId: diamondResults[0].shopifyVariantId || null,
            shopifyHandle: diamondResults[0].shopifyHandle || null,
            shopifyStores: mergedStores,
          }
        : {}),
    };
  });

  const mergedMapping = [
    ...newMapping,
    ...existingMapping.filter((existing) => !newMapping.some((entry) => entry.diamondId === existing.diamondId)),
  ];

  fs.writeFileSync(mappingFile, JSON.stringify(mergedMapping, null, 2), 'utf-8');
  console.log(`✓ Updated variant mapping with ${mergedMapping.length} entries`);
}

async function runFetchAndUpdate() {
  console.log('🔄 Starting VDB Diamond Fetch...\n');

  try {
    const config = loadConfig();
    const activeShops = getActiveShops(config);
    const shopifyStores = activeShops
      .map((shop) => shop.shopify)
      .filter((shopify) => shopify && (shopify.shopDomain || shopify.domain) && (shopify.accessToken || shopify.token));

    console.log('📡 Fetching diamonds from VDB API...');
    const response = await fetchDiamondsFromVDB(1, 100);

    if (!response.response || !response.response.body || !response.response.body.diamonds) {
      throw new Error('Invalid API response format');
    }

    const vdbDiamonds = response.response.body.diamonds;
    console.log(`✓ Retrieved ${vdbDiamonds.length} diamonds from API\n`);

    console.log('🔄 Mapping diamonds to schema...');
    const mappedDiamonds = vdbDiamonds.map(mapDiamondToSchema);

    console.log('\n💾 Saving diamonds...');
    for (const shop of activeShops) {
      saveDiamondsToFile(mappedDiamonds, shop.outputFile);
      console.log(`✓ Saved ${mappedDiamonds.length} diamonds to ${shop.outputFile}`);
    }

    console.log('📝 Updating variant mapping...');

    const shopifySync = await syncDiamondsToShopify(mappedDiamonds, { shopifyStores });
    if (!shopifySync.enabled) {
      console.log('ℹ Shopify sync skipped because credentials were not provided.');
    } else {
      const created = shopifySync.results.filter((result) => result.action === 'created').length;
      const updated = shopifySync.results.filter((result) => result.action === 'updated').length;
      const failed = shopifySync.results.filter((result) => result.error).length;

      console.log(`✓ Shopify sync complete: ${created} created, ${updated} updated, ${failed} failed`);
    }

    const mappingPath = config && config.output_paths && config.output_paths.variant_mapping_file
      ? config.output_paths.variant_mapping_file
      : DEFAULT_MAPPING_FILE;
    updateVariantMapping(mappedDiamonds, shopifySync.results || [], mappingPath);

    console.log('\n✅ Process completed successfully!\n');
    console.log('Summary:');
    console.log(`  • Total diamonds fetched: ${mappedDiamonds.length}`);
    console.log(`  • Saved to: ${activeShops.map((shop) => shop.outputFile).join(', ')}`);
    console.log(`  • Updated: ${mappingPath}`);

    if (mappedDiamonds.length > 0) {
      console.log('\n📊 Sample diamond:');
      console.log(JSON.stringify(mappedDiamonds[0], null, 2));
    }

    return {
      diamonds: mappedDiamonds,
      shopifySync,
    };
  } catch (error) {
    console.error('❌ Error:', error.message);
    throw error;
  }
}

async function main() {
  try {
    await runFetchAndUpdate();
  } catch (error) {
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  runFetchAndUpdate,
  mapDiamondToSchema,
  fetchDiamondsFromVDB,
  saveDiamondsToFile,
  updateVariantMapping,
};
