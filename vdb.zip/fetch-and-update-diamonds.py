#!/usr/bin/env python3
"""
VDB Diamond Fetch and Schema Update
Fetches diamonds from VDB API and maps them to the local schema
"""

import requests
import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

# Configuration
API_BASE_URL = "https://apiservices.vdbapp.com"
API_ENDPOINT = "/v2/diamonds"
AUTH_TOKEN = "iltz_Ie1tN0qm-ANqF7X6SRjwyhmMtzZsmqvyWOZ83I"
API_KEY = "_eTAh9su9_0cnehpDpqM9xA"
SHOP_NAME = "aaveri-2.myshopify.com"

# Output paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data" / "manual_diamonds"
OUTPUT_FILE = DATA_DIR / f"{SHOP_NAME}.json"
MAPPING_FILE = DATA_DIR / "shopify-variant-mapping.json"


def map_diamond_to_schema(vdb_diamond: Dict[str, Any]) -> Dict[str, Any]:
    """Map VDB API diamond fields to our schema"""
    return {
        "id": vdb_diamond.get("id"),
        "sku": f"VDB-{vdb_diamond.get('stock_num', vdb_diamond.get('id'))}",
        "vendorRef": f"vendor-{vdb_diamond.get('vendor_id')}" if vdb_diamond.get('vendor_id') else "aurum-diamond-house",
        "title": f"{vdb_diamond.get('shape', 'Round')} {vdb_diamond.get('size', 0)}ct {vdb_diamond.get('color', 'D')} {vdb_diamond.get('clarity', 'VS1')}",
        "shape": vdb_diamond.get("shape", "Round"),
        "growthType": "natural",
        "carat": float(vdb_diamond.get("size", 0)),
        "color": vdb_diamond.get("color", "D"),
        "clarity": vdb_diamond.get("clarity", "VS1"),
        "certificate": vdb_diamond.get("lab", "GIA"),
        "certificateUrl": vdb_diamond.get("cert_url", ""),
        "cut": vdb_diamond.get("cut", "Excellent"),
        "polish": vdb_diamond.get("polish", "Excellent"),
        "symmetry": vdb_diamond.get("symmetry", "Excellent"),
        "measurements": f"{vdb_diamond.get('meas_length', 0)}x{vdb_diamond.get('meas_width', 0)}x{vdb_diamond.get('meas_depth', 0)}",
        "tablePercent": float(vdb_diamond.get("table_percent", 0)),
        "depthPercent": float(vdb_diamond.get("depth_percent", 0)),
        "fluorescence": vdb_diamond.get("fluor_intensity", "None"),
        "price": vdb_diamond.get("total_sales_price") or vdb_diamond.get("price_per_carat", 0),
        "availability": "available" if vdb_diamond.get("available") else "unavailable",
        "publicationState": "published",
        "compatibleSettingIds": [],
        "accentColor": "#f7edcc",
        "cardCaption": f"{vdb_diamond.get('cut', 'Excellent')} cut, {vdb_diamond.get('polish', 'Excellent')} polish, {vdb_diamond.get('symmetry', 'Excellent')} symmetry",
        "origin": vdb_diamond.get("country", "USA"),
        "description": f"{vdb_diamond.get('shape', 'Round')} natural diamond certified by {vdb_diamond.get('lab', 'GIA')}.",
        "publishedAt": datetime.now().isoformat() + "Z",
        "imageUrl": vdb_diamond.get("image_url", ""),
        "variantId": str(vdb_diamond.get("id")),
    }


def fetch_diamonds_from_vdb(page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
    """Fetch diamonds from VDB API"""
    url = API_BASE_URL + API_ENDPOINT
    
    params = {
        "type": "Diamond",
        "page_number": page_number,
        "page_size": page_size,
        "markup_mode": "true",
        "show_unavailable": "true",
    }
    
    headers = {
        "Authorization": f"Token token={AUTH_TOKEN}, api_key={API_KEY}",
        "Cache-Control": "no-cache",
        "User-Agent": "Python Diamond Fetch",
    }
    
    print(f"📡 Fetching from: {url}")
    response = requests.get(url, params=params, headers=headers, timeout=30)
    response.raise_for_status()
    
    return response.json()


def save_diamonds_to_file(diamonds: List[Dict[str, Any]], filename: Path) -> None:
    """Save diamonds to JSON file"""
    filename.parent.mkdir(parents=True, exist_ok=True)
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(diamonds, f, indent=2, ensure_ascii=False)
    
    print(f"✓ Saved {len(diamonds)} diamonds to {filename}")


def update_variant_mapping(diamonds: List[Dict[str, Any]]) -> None:
    """Update variant mapping file"""
    # Load existing mapping if it exists
    existing_mapping = []
    if MAPPING_FILE.exists():
        with open(MAPPING_FILE, 'r', encoding='utf-8') as f:
            existing_mapping = json.load(f)
    
    # Create new mappings
    new_mapping = [
        {
            "diamondId": diamond["id"],
            "sku": diamond["sku"],
            "variantId": diamond["variantId"],
            "title": diamond["title"],
            "shape": diamond["shape"],
            "carat": diamond["carat"],
            "price": diamond["price"],
        }
        for diamond in diamonds
    ]
    
    # Merge with existing, avoiding duplicates
    existing_ids = {m["diamondId"] for m in existing_mapping}
    new_ids = {m["diamondId"] for m in new_mapping}
    
    merged_mapping = new_mapping + [
        m for m in existing_mapping 
        if m["diamondId"] not in new_ids
    ]
    
    MAPPING_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(MAPPING_FILE, 'w', encoding='utf-8') as f:
        json.dump(merged_mapping, f, indent=2, ensure_ascii=False)
    
    print(f"✓ Updated variant mapping with {len(merged_mapping)} entries")


def main():
    """Main execution"""
    print("🔄 Starting VDB Diamond Fetch...\n")
    
    try:
        # Fetch from API
        print("📡 Fetching diamonds from VDB API...")
        response = fetch_diamonds_from_vdb(1, 100)
        
        # Validate response
        if not response.get("response", {}).get("body", {}).get("diamonds"):
            raise ValueError("Invalid API response format")
        
        vdb_diamonds = response["response"]["body"]["diamonds"]
        print(f"✓ Retrieved {len(vdb_diamonds)} diamonds from API\n")
        
        # Map to schema
        print("🔄 Mapping diamonds to schema...")
        mapped_diamonds = [map_diamond_to_schema(d) for d in vdb_diamonds]
        
        # Save to files
        print("\n💾 Saving diamonds...")
        save_diamonds_to_file(mapped_diamonds, OUTPUT_FILE)
        
        # Update variant mapping
        print("📝 Updating variant mapping...")
        update_variant_mapping(mapped_diamonds)
        
        # Summary
        print("\n✅ Process completed successfully!\n")
        print("Summary:")
        print(f"  • Total diamonds fetched: {len(mapped_diamonds)}")
        print(f"  • Saved to: {OUTPUT_FILE.relative_to(BASE_DIR)}")
        print(f"  • Updated: {MAPPING_FILE.relative_to(BASE_DIR)}")
        
        # Show sample
        if mapped_diamonds:
            print("\n📊 Sample diamond:")
            print(json.dumps(mapped_diamonds[0], indent=2, ensure_ascii=False))
        
    except requests.exceptions.RequestException as e:
        print(f"❌ API Error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
