const https = require('https');

function normalizeShopifyConfig(shopify = {}) {
  const domain = shopify.shopDomain || shopify.domain || '';
  const accessToken = shopify.accessToken || shopify.token || '';
  const apiVersion = shopify.apiVersion || '2024-10';

  return {
    domain,
    accessToken,
    apiVersion,
    enabled: Boolean(domain && accessToken),
  };
}

function parseShopifyStores(overrides = {}) {
  const envStores = process.env.SHOPIFY_STORES_JSON;
  if (envStores) {
    try {
      const parsed = JSON.parse(envStores);
      if (Array.isArray(parsed)) {
        return parsed.map(normalizeShopifyConfig).filter((store) => store.enabled);
      }
    } catch (error) {
      throw new Error(`Failed to parse SHOPIFY_STORES_JSON: ${error.message}`);
    }
  }

  if (Array.isArray(overrides.shopifyStores) && overrides.shopifyStores.length > 0) {
    return overrides.shopifyStores.map(normalizeShopifyConfig).filter((store) => store.enabled);
  }

  return [];
}

function escapeGraphQLValue(value) {
  return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

function requestJson(config, method, requestPath, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : '';
    const options = {
      hostname: config.domain,
      path: `/admin/api/${config.apiVersion}${requestPath}`,
      method,
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': config.accessToken,
        'User-Agent': 'VDB Diamond Sync',
      },
    };

    if (payload) {
      options.headers['Content-Length'] = Buffer.byteLength(payload);
    }

    const req = https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        if (!data) {
          resolve({ statusCode: res.statusCode, body: null });
          return;
        }

        try {
          resolve({
            statusCode: res.statusCode,
            body: JSON.parse(data),
          });
        } catch (error) {
          reject(new Error(`Failed to parse Shopify response: ${error.message}`));
        }
      });
    });

    req.on('error', reject);

    if (payload) {
      req.write(payload);
    }

    req.end();
  });
}

async function graphqlRequest(config, query, variables) {
  const response = await requestJson(config, 'POST', '/graphql.json', {
    query,
    variables,
  });

  if (response.statusCode >= 400) {
    throw new Error(`Shopify GraphQL request failed with status ${response.statusCode}`);
  }

  if (response.body && response.body.errors && response.body.errors.length) {
    const message = response.body.errors.map((error) => error.message).join('; ');
    throw new Error(`Shopify GraphQL error: ${message}`);
  }

  return response.body ? response.body.data : null;
}

function buildProductBody(diamond) {
  return [
    `<p>${diamond.description || 'Diamond product.'}</p>`,
    '<ul>',
    `<li><strong>SKU:</strong> ${diamond.sku}</li>`,
    `<li><strong>Carat:</strong> ${diamond.carat}</li>`,
    `<li><strong>Shape:</strong> ${diamond.shape}</li>`,
    `<li><strong>Color:</strong> ${diamond.color}</li>`,
    `<li><strong>Clarity:</strong> ${diamond.clarity}</li>`,
    `<li><strong>Certificate:</strong> ${diamond.certificate}</li>`,
    '</ul>',
  ].join('');
}

async function findVariantBySku(config, sku) {
  const query = `
    query ($query: String!) {
      productVariants(first: 1, query: $query) {
        nodes {
          id
          legacyResourceId
          sku
          product {
            id
            legacyResourceId
            title
            handle
          }
        }
      }
    }
  `;

  const data = await graphqlRequest(config, query, {
    query: `sku:${escapeGraphQLValue(sku)}`,
  });

  const nodes = data && data.productVariants && data.productVariants.nodes ? data.productVariants.nodes : [];
  return nodes[0] || null;
}

async function updateExistingProduct(config, match, diamond) {
  const productId = match.product.legacyResourceId;
  const variantId = match.legacyResourceId;

  const productResponse = await requestJson(config, 'PUT', `/products/${productId}.json`, {
    product: {
      id: productId,
      title: diamond.title,
      body_html: buildProductBody(diamond),
      vendor: diamond.vendorRef,
      product_type: 'Diamond',
      status: 'active',
      handle: match.product.handle,
      tags: ['diamond', diamond.shape, diamond.certificate].filter(Boolean).join(', '),
    },
  });

  if (productResponse.statusCode >= 400) {
    throw new Error(`Failed to update Shopify product ${productId}`);
  }

  const variantResponse = await requestJson(config, 'PUT', `/variants/${variantId}.json`, {
    variant: {
      id: variantId,
      sku: diamond.sku,
      price: String(diamond.price || 0),
      inventory_management: null,
      inventory_policy: 'continue',
    },
  });

  if (variantResponse.statusCode >= 400) {
    throw new Error(`Failed to update Shopify variant ${variantId}`);
  }

  return {
    action: 'updated',
    shopifyProductId: productId,
    shopifyVariantId: variantId,
    shopifyHandle: match.product.handle,
  };
}

async function createProduct(config, diamond) {
  const handle = diamond.sku
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

  const response = await requestJson(config, 'POST', '/products.json', {
    product: {
      title: diamond.title,
      body_html: buildProductBody(diamond),
      vendor: diamond.vendorRef,
      product_type: 'Diamond',
      status: 'active',
      handle,
      tags: ['diamond', diamond.shape, diamond.certificate].filter(Boolean).join(', '),
      variants: [
        {
          sku: diamond.sku,
          price: String(diamond.price || 0),
          inventory_management: null,
          inventory_policy: 'continue',
          option1: 'Default Title',
        },
      ],
      options: [
        {
          name: 'Title',
          values: ['Default Title'],
        },
      ],
    },
  });

  if (response.statusCode >= 400) {
    throw new Error('Failed to create Shopify product');
  }

  const product = response.body && response.body.product ? response.body.product : null;
  const variant = product && product.variants && product.variants[0] ? product.variants[0] : null;

  return {
    action: 'created',
    shopifyProductId: product ? product.id : null,
    shopifyVariantId: variant ? variant.id : null,
    shopifyHandle: product ? product.handle : handle,
  };
}

async function syncDiamondToShopify(diamond, config) {
  const match = await findVariantBySku(config, diamond.sku);
  if (match && match.product && match.legacyResourceId) {
    return updateExistingProduct(config, match, diamond);
  }

  return createProduct(config, diamond);
}

async function syncDiamondsToShopify(diamonds, overrides = {}) {
  const stores = parseShopifyStores(overrides);

  if (!stores.length) {
    return {
      enabled: false,
      skipped: diamonds.length,
      results: [],
    };
  }

  const results = [];

  for (const store of stores) {
    for (const diamond of diamonds) {
      try {
        const result = await syncDiamondToShopify(diamond, store);
        results.push({
          diamondId: diamond.id,
          sku: diamond.sku,
          shopDomain: store.domain,
          ...result,
        });
      } catch (error) {
        results.push({
          diamondId: diamond.id,
          sku: diamond.sku,
          shopDomain: store.domain,
          error: error.message,
        });
      }
    }
  }

  return {
    enabled: true,
    skipped: 0,
    results,
  };
}

module.exports = {
  normalizeShopifyConfig,
  parseShopifyStores,
  syncDiamondToShopify,
  syncDiamondsToShopify,
};
